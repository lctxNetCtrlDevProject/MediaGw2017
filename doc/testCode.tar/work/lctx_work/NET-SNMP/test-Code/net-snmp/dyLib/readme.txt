#############################################################################
#@Desc: This is a demo from net-snmp project to add a MIB file and it's related
#	dynamically loadable library to net-snmp agent, snmpd.
#Ref:	http://www.net-snmp.org/wiki/index.php/TUT:Writing_a_Dynamically_Loadable_Object
#@Author: Andy-wei.hou
#@Log:	  created by Andy-wei.hou, 2017.02.12
#############################################################################
#1. Copy MIB file to system mib file dirs
sudo cp NET-SNMP-TUTORIAL-MIB.txt /usr/local/share/snmp/mibs/ -rf

#2. Configure enviroments variabies
export MIBDIRS=/usr/local/share/snmp/mibs/

#3. Add MIBName,which appear in MIB file start with ::= BEGIN ,to MIBS.
#eg. "NET-SNMP-TUTORIAL-MIB DEFINITIONS ::= BEGIN","NET-SNMP-TUTORIAL-MIB" is MIBName 
export MIBS="+NET-SNMP-TUTORIAL-MIB"

#4. using snmptranslate to check the validation of MIB file
# "snmptranslate -Tp -IR ${mibId}"
snmptranslate -Tp -IR netSnmpTutorialMIB
#note, mibModuleID defined by MIB file by following "MODULE-IDENTITY"
#likely:"netSnmpTutorialMIB MODULE-IDENTITY", 
#in which, "netSnmpTutorialMIB" is the mibModuleID

#5. using mib2c to translate MIB file to a .c & .h file
# "mib2c -c ${transConfigFile} ${mibID}"
mib2c -c mib2c.scalar.conf netSnmpTutorialMIB
#note, transConfigFile all stored in "/usr/local/share/snmp/*.conf"
#if "-c" option not specificed, mib2c will auto detect MIB files, and ask you to select proper transConfigFile
#Warning, mib2c only can translate one type of MIB variablies once, eg "scalar","table","notification"
#So, if your MIB files contained multiple-variablies type, you have to using "mib2c" to translate 
#one type by one type, then merge the .c & .h file manually.


#6. Add dlmod cmd to snmpd.conf to let snmpd load dynamically loadable library 
# "dlmod ${MIBmoduleID} ${pathOfLib}"
dlmod netSnmpTutorialMIB /work/testCode/net-snmp/dyLib/netSnmpTutorialMIB.so
#note, MIBmoduleID is in MIB file following by "MODULE-IDENTITY" or in .c file using "init_${MIBModuleID}()" func

#7. Test 
snmpget -v2c -c public localhost NET-SNMP-TUTORIAL-MIB::nstAgentPluginObject.0
snmpget -v2c -c public localhost 1.3.6.1.4.1.8072.2.4.1.1.3.0

snmpget -v2c -c public localhost 1.3.6.1.4.1.8072.2.4.1.1.1.0
snmpget -v2c -c public localhost 1.3.6.1.4.1.8072.2.4.1.1.2.0






