#ifndef __DELAYED_INSTANCE_H__
#define __DELAYED_INSTANCE_H__

#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>


int
delayed_instance_handler(netsnmp_mib_handler *handler,
                         netsnmp_handler_registration *reginfo,
                         netsnmp_agent_request_info *reqinfo,
                         netsnmp_request_info *requests);
void
return_delayed_response(unsigned int clientreg, void *clientarg);

#endif
