#ifndef __NOTIFICATION_H__
#define __NOTIFICATION_H__

extern void send_example_notification(unsigned int clientreg, void *clientarg);


#endif
