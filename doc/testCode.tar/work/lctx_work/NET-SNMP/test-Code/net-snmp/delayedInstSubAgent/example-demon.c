#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-includes.h>
#include <net-snmp/agent/net-snmp-agent-includes.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <nstAgentSubagentObject.h>


static int keep_running;

void dispBuf(unsigned char *buf, int len, const char *name){
	int i = 0;
	if(!buf || len <= 0)
		return;
	if(name)
		snmp_log(LOG_WARNING,"/r/n%s[",name);
	else
		snmp_log(LOG_WARNING,"/r/n[");
	for(i =0; i<len; i++){
		snmp_log(LOG_WARNING,"  %02X",buf[i]);
	}
	snmp_log(LOG_WARNING,"]/r/n");
}


int osa_udpCreateBindSock(char *ipaddr, unsigned short port){
	int local_sockfd;
	struct sockaddr_in local_address;
	int len;
	int  iSockopt;

	local_sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(local_sockfd == -1)
	{
		snmp_log(LOG_WARNING,"Create udp socket fail, errno[%d]",errno);
	}
	memset(&local_address,0x00, sizeof(local_address));
	local_address.sin_family = AF_INET;
	if (NULL == ipaddr)
	{
		local_address.sin_addr.s_addr = inet_addr("0.0.0.0");
	}
	else
	{
		local_address.sin_addr.s_addr = inet_addr(ipaddr);
	}
	local_address.sin_port = htons(port);


	iSockopt = 1;
	//设置Socket属性：SO_REUSEADDR：允许在bind过程中本地地址重复使用
    if (0  > setsockopt(local_sockfd, SOL_SOCKET, SO_REUSEADDR, (const char *)&iSockopt, sizeof(int)))
	{
		close(local_sockfd);
		return -1;
	}

	len=sizeof(local_address);
	if (-1 == bind(local_sockfd, (struct sockaddr *)&local_address, len))
	{
		snmp_log(LOG_WARNING,"port =%d socket bind error!,errno=%d",port,errno);
		return -1;
	}
	snmp_log(LOG_WARNING,"bind Success with port=%d",port);
	return(local_sockfd);
}


void pduProcThr(){
	int fd = -1;
	struct sockaddr_in fromAddr;
	int fromAddrLen ;
	fd_set fSets;
	struct timeval time_out;
	int iRet = -1;
	unsigned char buf[1000];

	fromAddrLen = sizeof(fromAddr);
	
	fd = osa_udpCreateBindSock(NULL,50002);
	
	snmp_log(LOG_WARNING,"Thread %s Running, fd=%d \r\n",__func__,fd);


	while(1)
		{
		FD_ZERO(&fSets);
		FD_SET(fd,&fSets);
		time_out.tv_sec  = 1;
		time_out.tv_usec = 500*1000;

		iRet= select(fd+1, &fSets,  NULL, NULL,  &time_out);
		//snmp_log(LOG_WARNING," iRet =%d  \r\n",iRet);
		if(iRet > 0){		
			if(FD_ISSET(fd,&fSets)){
				memset(buf,0x00,sizeof(buf));
				iRet = recvfrom(fd, buf, sizeof(buf), 0,  (struct sockaddr *)&fromAddr, &fromAddrLen);
				if(iRet > 0){
					dispBuf (buf,iRet,__func__);
				}
				else{
					snmp_log(LOG_WARNING,"recvfrom fail,errno=%d",errno);
				}
			}
		}	
		
	}

		
}

void init_procThr(){
	pthread_t handle;
	int rel=0;
    rel = pthread_create(&handle, NULL, pduProcThr, NULL);
	if(rel != 0){
		snmp_log(LOG_WARNING,"Create Thread Fail,errno=%d",errno);
	}
}


RETSIGTYPE
stop_server(int a) {
    keep_running = 0;
}

int
main (int argc, char **argv) {
  int agentx_subagent=1; /* change this if you want to be a SNMP master agent */
  int background = 0; /* change this if you want to run in the background */
  int syslog = 0; /* change this if you want to use syslog */

	init_procThr();
  /* print log errors to syslog or stderr */
  if (syslog)
    snmp_enable_calllog();
  else
    snmp_enable_stderrlog();

  /* we're an agentx subagent? */
  if (agentx_subagent) {
    /* make us a agentx client. */
    netsnmp_ds_set_boolean(NETSNMP_DS_APPLICATION_ID, NETSNMP_DS_AGENT_ROLE, 1);
  }

  /* run in background, if requested */
  if (background && netsnmp_daemonize(1, !syslog))
      exit(1);

  /* initialize tcpip, if necessary */
  SOCK_STARTUP;

  /* initialize the agent library */
  init_agent("example-demon");

  /* initialize mib code here */

  /* mib code: init_nstAgentSubagentObject from nstAgentSubagentObject.C */
  init_nstAgentSubagentObject();  

  /* initialize vacm/usm access control  */
  if (!agentx_subagent) {
      init_vacm_vars();
      init_usmUser();
  }

  /* example-demon will be used to read example-demon.conf files. */
  init_snmp("example-demon");

  /* If we're going to be a snmp master agent, initial the ports */
  if (!agentx_subagent)
    init_master_agent();  /* open the port to listen on (defaults to udp:161) */

  /* In case we recevie a request to stop (kill -TERM or kill -INT) */
  keep_running = 1;
  signal(SIGTERM, stop_server);
  signal(SIGINT, stop_server);

  snmp_log(LOG_INFO,"example-demon is up and running.\n");

  /* your main loop here... */
  while(keep_running) {
    /* if you use select(), see snmp_select_info() in snmp_api(3) */
    /*     --- OR ---  */
    agent_check_and_process(1); /* 0 == don't block */
  }

  /* at shutdown time */
  snmp_shutdown("example-demon");
  SOCK_CLEANUP;

  return 0;
}

