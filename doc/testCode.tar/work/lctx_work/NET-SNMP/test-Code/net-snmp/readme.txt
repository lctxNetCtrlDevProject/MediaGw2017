.
├── delayedInst		-- alarm (timer mechanism in netsnmp) & cache example
├── dyLib			-- dynamically loadable MIB module example
├── notify			-- snmpv2 notification example
├── scalarInst		-- scalar example
├── table			-- table example, XX, don't know how to add or modify tables when access by GET
├── readme.txt		-- this file




snmpget -v2c -c public localhost 1.3.6.1.4.1.8072.2.1.1.0

snmpget -v2c -c public localhost 1.3.6.1.4.1.8072.2.1.2.0

snmpwalk -v 1 -c public localhost 1.3.6.1.4.1.8072.2.2.1


snmptrap -v 1 -c public localhost UCD-TRAP-TEST-MIB::demotraps "" 6 17 "" SNMPv2-MIB::sysLocation.0 s "Just here"

snmptrap -v 2c -c public localhost "" UCD-NOTIFICATION-TEST-MIB::demoNotif SNMPv2-MIB::sysLocation.0 s "Just here"



##struct in net-snmp
http://www.net-snmp.org/dev/agent/annotated.html

###############################################
#	Nofitication  releated

#****1. Local start snmptrapd to listen and receive trap from agent
#1.1 Add below lines to /usr/local/etc/snmp/snmptrapd.conf
/**********Content Add to snmptrapd.conf**********/
authCommunity log,execute,net public 

#1.2 start snmptrapd

snmptrapd -df -Lo -c /usr/local/etc/snmp/snmptrapd.conf

#note, if *:162 port occupied by some tsk, using "sudo netstate -anp | grep 162" to find the tsk and killed it by root before start snmptrapd

#***2. Add configurations in /usr/local/etc/snmp/snmpd.conf to configure the destinations of send_easy_trap(),send_v2trap(),netsnmp_send_traps()
# From: http://www.net-snmp.org/wiki/index.php/FAQ:Agent_17
# 
##--------Contents Add to snmpd.conf-------##
# send v1 traps
trapsink   127.0.0.1:162
trapsink   192.168.8.10:162
# also send v2 traps
# confiuration determined the destionation of send_v2trap(), snmp will fork the trap to all destinations
trap2sink  127.0.0.1:162
trap2sink  192.168.8.10:162
informsink 127.0.0.1:162
informsink 192.168.8.10:162

#-----------End---------------------------##	

#3***. created MIB files to define notification
eg. ./notifiy/UCD-TRAP-TEST-MIB.txt
#3.1 using snmptranslate to check the MIB files
sudo cp ./notify/UCD-TRAP-TEST-MIB.txt /usr/local/share/snmp/mibs/ -rf
export MIBDIRS=/usr/local/share/snmp/mibs/
export MIBS="+UCD-TRAP-TEST-MIB"
snmptranslate  -Tp -IR ucdNotificationTestMib
+--ucdNotificationTestMib(0)
   |
   +--demotraps(990)
      |
      +--demonotifs(0)
         |
         +--demoNotif(18)

#3.2 using mib2c to generate .c & .h files
mib2c -c mib2c.notify.conf ucdNotificationTestMib

#3.3 fill some codes for ucdNotificationTestMib.c & ucdNotificationTestMib.h 
#Then make it
#3.4 adducdNotificationTestMib.so to snmd.conf to load it dynamically
#3.5 agent will periodicly traped/10seconds


