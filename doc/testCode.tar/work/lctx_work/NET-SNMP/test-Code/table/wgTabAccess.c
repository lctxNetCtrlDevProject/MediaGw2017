#include <stdio.h>
#include <stdlib.h>
#include "wgTabAccess.h"




/************Global variablies***********/
WG_TAB_TYPE g_wgTab[TAB_ITEM];

void initWgTab(){
	int i =0;
	WG_TAB_TYPE *entry = NULL;
	for(i = 0; i < TAB_ITEM; i++){
		entry = &g_wgTab[i];
		sprintf(entry->name,"name_%d",i);
		sprintf(entry->chair1,"ch1_%d",i);
		sprintf(entry->chair2,"ch2_%d",i);
	}
}

void updateWgTab(){
	//Do something here to update the g_wgTab by yourself
}



WG_TAB_TYPE *getWgTab(int *item){
	*item = TAB_ITEM;
	return g_wgTab;
}

