#ifndef __WG_TAB_ACCESS_H__
#define __WG_TAB_ACCESS_H__

#define STR_LEN 10
#define TAB_ITEM 10

typedef struct{
	char name[STR_LEN];
	char chair1[STR_LEN];
	char chair2[STR_LEN];	
}WG_TAB_TYPE;


extern void initWgTab();
extern void updateWgTab();
extern WG_TAB_TYPE *getWgTab(int *item);


#endif